package com.example.sipamrt

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONObject
import java.util.concurrent.Executors

class DashboardActivity : AppCompatActivity() {

    private val executor = Executors.newSingleThreadExecutor()

    private var userId = 0
    private var userNama = ""
    private var userEmail = ""

    private lateinit var tvNamaWarga: TextView
    private lateinit var tvTotalAduan: TextView
    private lateinit var tvMenunggu: TextView
    private lateinit var tvDiproses: TextView
    private lateinit var tvSelesai: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_dashboard)

        // Mengambil data pengguna dari LoginActivity
        userId = intent.getIntExtra("USER_ID", 0)
        userNama = intent.getStringExtra("USER_NAMA") ?: ""
        userEmail = intent.getStringExtra("USER_EMAIL") ?: ""

        // Menghubungkan komponen tampilan
        tvNamaWarga = findViewById(R.id.tvNamaWarga)
        tvTotalAduan = findViewById(R.id.tvTotalAduan)
        tvMenunggu = findViewById(R.id.tvMenunggu)
        tvDiproses = findViewById(R.id.tvDiproses)
        tvSelesai = findViewById(R.id.tvSelesai)

        tvNamaWarga.text = "Selamat Datang, $userNama"

        // Tombol Buat Aduan
        findViewById<Button>(R.id.btnBuatAduan).setOnClickListener {
            val intent = Intent(this, AduanActivity::class.java)
            intent.putExtra("USER_ID", userId)
            intent.putExtra("USER_NAMA", userNama)
            intent.putExtra("USER_EMAIL", userEmail)
            startActivity(intent)
        }

        // Tombol Riwayat Aduan
        findViewById<TextView>(R.id.btnRiwayat).setOnClickListener {
            val intent = Intent(this, RiwayatActivity::class.java)
            intent.putExtra("USER_ID", userId)
            intent.putExtra("USER_NAMA", userNama)
            intent.putExtra("USER_EMAIL", userEmail)
            startActivity(intent)
        }

        // Tombol Profil
        findViewById<TextView>(R.id.btnProfil).setOnClickListener {
            val intent = Intent(this, ProfilActivity::class.java)
            intent.putExtra("USER_ID", userId)
            intent.putExtra("USER_NAMA", userNama)
            intent.putExtra("USER_EMAIL", userEmail)
            startActivity(intent)
        }

        // Tombol Keluar
        findViewById<TextView>(R.id.btnKeluar).setOnClickListener {
            val intent = Intent(this, LoginActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or
                    Intent.FLAG_ACTIVITY_CLEAR_TASK
            startActivity(intent)
            finish()
        }

        // Mengambil statistik aduan pengguna
        ambilStatistik()
    }

    private fun ambilStatistik() {

        if (userId <= 0) {
            Toast.makeText(
                this,
                "ID pengguna tidak ditemukan. Silakan login kembali.",
                Toast.LENGTH_LONG
            ).show()
            return
        }

        executor.execute {

            try {
                // Mengirim USER_ID ke statistik.php
                val request = JSONObject()
                request.put("user_id", userId)

                val response = ApiClient.post(
                    "statistik.php",
                    request
                )

                // Memeriksa respons dari PHP
                if (!response.optBoolean("success", false)) {
                    throw Exception(
                        response.optString(
                            "message",
                            "Gagal mengambil statistik"
                        )
                    )
                }

                // Mengambil angka statistik
                val total = response.optInt("total", 0)
                val menunggu = response.optInt("menunggu", 0)
                val diproses = response.optInt("diproses", 0)
                val selesai = response.optInt("selesai", 0)

                // Memperbarui tampilan Dashboard
                runOnUiThread {

                    tvTotalAduan.text = "Total Aduan: $total"
                    tvMenunggu.text = menunggu.toString()
                    tvDiproses.text = diproses.toString()
                    tvSelesai.text = selesai.toString()

                }

            } catch (e: Exception) {

                runOnUiThread {
                    Toast.makeText(
                        this,
                        "Statistik gagal dimuat: ${e.message}",
                        Toast.LENGTH_LONG
                    ).show()
                }

            }
        }
    }

    override fun onDestroy() {
        executor.shutdown()
        super.onDestroy()
    }
}