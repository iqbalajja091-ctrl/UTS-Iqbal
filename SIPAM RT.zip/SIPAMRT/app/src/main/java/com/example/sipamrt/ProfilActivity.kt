
package com.example.sipamrt

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class ProfilActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profil)

        val tvNama = findViewById<TextView>(R.id.tvNamaProfil)
        val tvEmail = findViewById<TextView>(R.id.tvEmailProfil)
        val tvId = findViewById<TextView>(R.id.tvIdProfil)
        val btnKembali = findViewById<Button>(R.id.btnKembaliProfil)

        // Mengambil data pengguna
        val nama = intent.getStringExtra("USER_NAMA") ?: "-"
        val email = intent.getStringExtra("USER_EMAIL") ?: "-"
        val userId = intent.getIntExtra("USER_ID", -1)

        // Menampilkan data pengguna
        tvNama.text = nama
        tvEmail.text = email
        tvId.text = if (userId != -1) userId.toString() else "-"

        // Tombol kembali
        btnKembali.setOnClickListener {
            finish()
        }
    }
}
