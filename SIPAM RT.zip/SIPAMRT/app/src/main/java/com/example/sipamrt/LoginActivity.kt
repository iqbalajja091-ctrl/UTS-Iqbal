
package com.example.sipamrt

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONObject

class LoginActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        val email = findViewById<EditText>(R.id.etEmail)
        val password = findViewById<EditText>(R.id.etPassword)

        val btnLogin = findViewById<Button>(R.id.btnLogin)
        val tvRegister = findViewById<TextView>(R.id.tvRegister)

        btnLogin.setOnClickListener {

            val inputEmail = email.text.toString().trim()
            val inputPassword = password.text.toString()

            if (
                inputEmail.isEmpty() ||
                inputPassword.isEmpty()
            ) {
                Toast.makeText(
                    this,
                    "Email dan password wajib diisi",
                    Toast.LENGTH_SHORT
                ).show()

                return@setOnClickListener
            }

            // Menyiapkan data JSON
            val data = JSONObject().apply {
                put("email", inputEmail)
                put("password", inputPassword)
            }

            btnLogin.isEnabled = false
            btnLogin.text = "Memeriksa..."

            // Menghubungi PHP API
            Thread {

                try {
                    val response = ApiClient.post(
                        "login.php",
                        data
                    )

                    val berhasil = response.optBoolean("status")
                    val pesan = response.optString("pesan")

                    val dataPengguna = response.optJSONObject("data")

                    runOnUiThread {

                        btnLogin.isEnabled = true
                        btnLogin.text = "Login"

                        if (berhasil && dataPengguna != null) {

                            val intent = Intent(
                                this,
                                DashboardActivity::class.java
                            )

                            // Mengirim identitas pengguna ke Dashboard
                            intent.putExtra(
                                "USER_ID",
                                dataPengguna.optInt("id")
                            )

                            intent.putExtra(
                                "USER_NAMA",
                                dataPengguna.optString("nama")
                            )

                            intent.putExtra(
                                "USER_EMAIL",
                                dataPengguna.optString("email")
                            )

                            startActivity(intent)
                            finish()

                        } else {

                            Toast.makeText(
                                this,
                                pesan,
                                Toast.LENGTH_LONG
                            ).show()
                        }
                    }

                } catch (e: Exception) {

                    runOnUiThread {

                        btnLogin.isEnabled = true
                        btnLogin.text = "Login"

                        Toast.makeText(
                            this,
                            "Gagal menghubungi server: ${e.message}",
                            Toast.LENGTH_LONG
                        ).show()
                    }
                }

            }.start()
        }

        tvRegister.setOnClickListener {

            val intent = Intent(
                this,
                RegisterActivity::class.java
            )

            startActivity(intent)
        }
    }
}
