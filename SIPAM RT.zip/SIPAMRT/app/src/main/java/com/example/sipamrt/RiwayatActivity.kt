
package com.example.sipamrt

import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONObject

class RiwayatActivity : AppCompatActivity() {

    private lateinit var tvInfo: TextView
    private lateinit var layoutDaftar: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_riwayat)

        tvInfo = findViewById(R.id.tvInfoRiwayat)
        layoutDaftar = findViewById(R.id.layoutDaftarAduan)

        val userId = intent.getIntExtra("USER_ID", -1)

        if (userId == -1) {
            Toast.makeText(
                this,
                "ID pengguna tidak ditemukan",
                Toast.LENGTH_SHORT
            ).show()
            finish()
            return
        }

        muatRiwayat(userId)
    }

    private fun muatRiwayat(userId: Int) {

        tvInfo.text = "Memuat riwayat aduan..."

        Thread {
            try {
                val data = JSONObject()
                data.put("user_id", userId)

                val response = ApiClient.post(
                    "riwayat_aduan.php",
                    data
                )

                runOnUiThread {

                    if (response.optBoolean("status")) {

                        val daftar = response.optJSONArray("data")

                        layoutDaftar.removeAllViews()

                        if (daftar == null || daftar.length() == 0) {
                            tvInfo.text = "Kamu belum memiliki aduan."
                            return@runOnUiThread
                        }

                        tvInfo.text =
                            "Jumlah aduan: ${daftar.length()}"

                        for (i in 0 until daftar.length()) {
                            val aduan = daftar.getJSONObject(i)
                            tampilkanAduan(aduan)
                        }

                    } else {
                        tvInfo.text = response.optString(
                            "pesan",
                            "Gagal memuat riwayat aduan"
                        )
                    }
                }

            } catch (e: Exception) {

                runOnUiThread {
                    tvInfo.text = "Gagal terhubung ke server."

                    Toast.makeText(
                        this,
                        e.message ?: "Terjadi kesalahan",
                        Toast.LENGTH_LONG
                    ).show()
                }
            }
        }.start()
    }

    private fun tampilkanAduan(aduan: JSONObject) {

        val kartu = LinearLayout(this)
        kartu.orientation = LinearLayout.VERTICAL
        kartu.setPadding(20, 18, 20, 18)

        val background = GradientDrawable()
        background.setColor(Color.WHITE)
        background.cornerRadius = 24f
        kartu.background = background

        val params = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        )

        params.bottomMargin = 20
        kartu.layoutParams = params

        // JUDUL
        tambahTeks(
            kartu,
            aduan.optString("judul", "Tanpa judul"),
            19,
            true,
            "#173D2C"
        )

        // KATEGORI
        tambahTeks(
            kartu,
            "Kategori: ${aduan.optString("kategori", "-")}",
            13,
            false,
            "#16865B"
        )

        tambahGaris(kartu)

        // DESKRIPSI
        tambahTeks(
            kartu,
            "Deskripsi",
            13,
            true,
            "#26332C"
        )

        tambahTeks(
            kartu,
            aduan.optString("deskripsi", "-"),
            14,
            false,
            "#59645E"
        )

        // LOKASI
        tambahTeks(
            kartu,
            "Lokasi: ${aduan.optString("lokasi", "-")}",
            13,
            false,
            "#59645E"
        )

        tambahGaris(kartu)

        // STATUS
        val status = aduan.optString("status", "Menunggu")
        tambahStatus(kartu, status)

        // TANGGAL
        tambahTeks(
            kartu,
            "Tanggal: ${aduan.optString("created_at", "-")}",
            12,
            false,
            "#89938D"
        )

        // TANGGAPAN RT
        val tanggapan = aduan.optString("tanggapan", "")

        if (tanggapan.isNotBlank() && tanggapan != "null") {

            tambahTeks(
                kartu,
                "TANGGAPAN RT",
                12,
                true,
                "#16865B"
            )

            tambahTeks(
                kartu,
                tanggapan,
                14,
                false,
                "#286347"
            )
        }

        // FOTO
        val foto = aduan.optString("foto", "")

        if (foto.isNotBlank() && foto != "null") {
            tambahTeks(
                kartu,
                "Bukti foto: $foto",
                12,
                false,
                "#64748B"
            )
        }

        layoutDaftar.addView(kartu)
    }

    private fun tambahStatus(
        parent: LinearLayout,
        status: String
    ) {

        val label = TextView(this)
        label.text = "STATUS: $status"
        label.textSize = 12f
        label.setTypeface(null, Typeface.BOLD)
        label.setTextColor(Color.parseColor(warnaStatus(status)))
        label.setPadding(14, 9, 14, 9)

        val bg = GradientDrawable()
        bg.cornerRadius = 30f
        bg.setColor(Color.parseColor(latarStatus(status)))

        label.background = bg

        val params = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        )

        params.topMargin = 8
        params.bottomMargin = 8

        label.layoutParams = params

        parent.addView(label)
    }

    private fun tambahGaris(parent: LinearLayout) {

        val garis = android.view.View(this)

        garis.setBackgroundColor(Color.parseColor("#E8EEEA"))

        val params = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            1
        )

        params.topMargin = 12
        params.bottomMargin = 12

        garis.layoutParams = params

        parent.addView(garis)
    }

    private fun tambahTeks(
        parent: LinearLayout,
        isi: String,
        ukuran: Int,
        tebal: Boolean,
        warna: String
    ) {

        val teks = TextView(this)

        teks.text = isi
        teks.textSize = ukuran.toFloat()
        teks.setTextColor(Color.parseColor(warna))
        teks.setPadding(0, 6, 0, 6)

        if (tebal) {
            teks.setTypeface(null, Typeface.BOLD)
        }

        parent.addView(teks)
    }

    private fun warnaStatus(status: String): String {
        return when (status) {
            "Menunggu" -> "#B7791F"
            "Diproses" -> "#2563EB"
            "Selesai" -> "#16865B"
            "Ditolak" -> "#DC2626"
            else -> "#475569"
        }
    }

    private fun latarStatus(status: String): String {
        return when (status) {
            "Menunggu" -> "#FFF4D6"
            "Diproses" -> "#E7F0FF"
            "Selesai" -> "#E3F5E9"
            "Ditolak" -> "#FDE8E8"
            else -> "#F1F5F9"
        }
    }
}
