package com.example.sipamrt

import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.Spinner
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONObject

class AduanActivity : AppCompatActivity() {

    // Menyimpan URI foto yang dipilih
    private var fotoUri: Uri? = null

    // Menyimpan daftar kategori dari database
    private val daftarKategori = mutableListOf<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_aduan)

        // 1. Mengambil ID pengguna
        val userId = intent.getIntExtra("USER_ID", -1)

        // 2. Menghubungkan komponen XML
        val kategori = findViewById<Spinner>(R.id.spKategori)

        val judul = findViewById<EditText>(R.id.etJudulAduan)
        val deskripsi = findViewById<EditText>(R.id.etDeskripsi)
        val lokasi = findViewById<EditText>(R.id.etLokasi)

        val btnPilihFoto =
            findViewById<Button>(R.id.btnPilihFoto)

        val btnKirim =
            findViewById<Button>(R.id.btnKirimAduan)

        val imgBukti =
            findViewById<ImageView>(R.id.imgBukti)

        // 3. Menampilkan kategori sementara
        daftarKategori.clear()
        daftarKategori.add("Memuat kategori...")

        val adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_item,
            daftarKategori
        )

        adapter.setDropDownViewResource(
            android.R.layout.simple_spinner_dropdown_item
        )

        kategori.adapter = adapter

        // 4. Mengambil kategori dari database melalui API
        Thread {
            try {

                val response = ApiClient.post(
                    "daftar_kategori.php",
                    JSONObject()
                )

                val berhasil = response.optBoolean("status")

                if (!berhasil) {
                    throw Exception(
                        response.optString(
                            "pesan",
                            "Gagal mengambil kategori"
                        )
                    )
                }

                val data = response.optJSONArray("data")
                    ?: throw Exception("Data kategori tidak ditemukan")

                val kategoriBaru = mutableListOf<String>()

                for (i in 0 until data.length()) {
                    val item = data.getJSONObject(i)

                    val namaKategori =
                        item.optString("nama_kategori")

                    if (namaKategori.isNotBlank()) {
                        kategoriBaru.add(namaKategori)
                    }
                }

                runOnUiThread {

                    daftarKategori.clear()
                    daftarKategori.add("Pilih Kategori Aduan")
                    daftarKategori.addAll(kategoriBaru)

                    adapter.notifyDataSetChanged()

                    if (kategoriBaru.isEmpty()) {
                        Toast.makeText(
                            this,
                            "Belum ada kategori yang aktif",
                            Toast.LENGTH_LONG
                        ).show()
                    } else {
                        Toast.makeText(
                            this,
                            "Kategori berhasil dimuat",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                }

            } catch (e: Exception) {

                runOnUiThread {

                    daftarKategori.clear()
                    daftarKategori.add("Gagal memuat kategori")

                    adapter.notifyDataSetChanged()

                    Toast.makeText(
                        this,
                        "Gagal mengambil kategori: ${e.message}",
                        Toast.LENGTH_LONG
                    ).show()
                }
            }

        }.start()

        // 5. Memilih foto dari galeri HP
        val pilihFoto = registerForActivityResult(
            ActivityResultContracts.GetContent()
        ) { uri ->

            if (uri != null) {

                fotoUri = uri

                imgBukti.setImageURI(uri)
                imgBukti.visibility = View.VISIBLE

                Toast.makeText(
                    this,
                    "Foto bukti berhasil dipilih",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }

        btnPilihFoto.setOnClickListener {
            pilihFoto.launch("image/*")
        }

        // 6. Tombol kirim aduan
        btnKirim.setOnClickListener {

            val inputJudul = judul.text.toString().trim()
            val inputDeskripsi = deskripsi.text.toString().trim()
            val inputLokasi = lokasi.text.toString().trim()

            val inputKategori =
                kategori.selectedItem?.toString() ?: ""

            // Memeriksa ID pengguna
            if (userId <= 0) {

                Toast.makeText(
                    this,
                    "ID pengguna tidak ditemukan. Silakan login kembali.",
                    Toast.LENGTH_LONG
                ).show()

                return@setOnClickListener
            }

            // Memeriksa kategori
            if (
                kategori.selectedItemPosition == 0 ||
                inputKategori == "Gagal memuat kategori" ||
                inputKategori == "Memuat kategori..."
            ) {

                Toast.makeText(
                    this,
                    "Silakan pilih kategori yang tersedia",
                    Toast.LENGTH_SHORT
                ).show()

                return@setOnClickListener
            }

            // Memeriksa kolom wajib
            if (
                inputJudul.isEmpty() ||
                inputDeskripsi.isEmpty() ||
                inputLokasi.isEmpty()
            ) {

                Toast.makeText(
                    this,
                    "Semua kolom wajib diisi",
                    Toast.LENGTH_SHORT
                ).show()

                return@setOnClickListener
            }

            // 7. Menyiapkan data pengaduan
            val dataAduan = mapOf(
                "user_id" to userId.toString(),
                "kategori" to inputKategori,
                "judul" to inputJudul,
                "deskripsi" to inputDeskripsi,
                "lokasi" to inputLokasi
            )

            // Mencegah tombol ditekan berulang kali
            btnKirim.isEnabled = false
            btnKirim.text = "Mengirim Aduan..."

            // 8. Mengirim data ke PHP API
            Thread {

                try {

                    val response = ApiClient.postMultipart(
                        this@AduanActivity,
                        "buat_aduan.php",
                        dataAduan,
                        fotoUri
                    )

                    val berhasil =
                        response.optBoolean("status")

                    val pesan =
                        response.optString("pesan")

                    val idAduan =
                        response.optInt("pengaduan_id")

                    runOnUiThread {

                        btnKirim.isEnabled = true
                        btnKirim.text = "Kirim Aduan"

                        if (berhasil) {

                            Toast.makeText(
                                this,
                                "$pesan. Nomor aduan: $idAduan",
                                Toast.LENGTH_LONG
                            ).show()

                            // Kembali ke Dashboard setelah berhasil
                            finish()

                        } else {

                            Toast.makeText(
                                this,
                                pesan,
                                Toast.LENGTH_LONG
                            ).show()
                        }
                    }

                } catch (e: Exception) {

                    runOnUiThread {

                        btnKirim.isEnabled = true
                        btnKirim.text = "Kirim Aduan"

                        Toast.makeText(
                            this,
                            "Gagal mengirim aduan: ${e.message}",
                            Toast.LENGTH_LONG
                        ).show()
                    }
                }

            }.start()
        }
    }
}
