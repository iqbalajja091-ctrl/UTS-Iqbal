package com.example.sipamrt
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import android.content.Context
import android.net.Uri
import java.io.DataOutputStream

object ApiClient {

    private const val BASE_URL =
        "http://192.168.1.33/sipam_api/"

    fun post(
        endpoint: String,
        data: JSONObject
    ): JSONObject {

        val url = URL(BASE_URL + endpoint)
        val connection = url.openConnection() as HttpURLConnection

        try {
            connection.requestMethod = "POST"
            connection.connectTimeout = 15000
            connection.readTimeout = 15000
            connection.doOutput = true

            connection.setRequestProperty(
                "Content-Type",
                "application/json; charset=UTF-8"
            )

            connection.setRequestProperty(
                "Accept",
                "application/json"
            )

            connection.outputStream.use { output ->
                output.write(data.toString().toByteArray(Charsets.UTF_8))
            }

            val responseCode = connection.responseCode

            val responseStream =
                if (responseCode in 200..299) {
                    connection.inputStream
                } else {
                    connection.errorStream
                }

            val responseText = responseStream
                ?.bufferedReader()
                ?.use { it.readText() }
                ?: """{"status":false,"pesan":"Respons server kosong"}"""

            return JSONObject(responseText)

        } finally {
            connection.disconnect()
        }
    }

    fun postMultipart(
        context: Context,
        endpoint: String,
        fields: Map<String, String>,
        fotoUri: Uri?
    ): JSONObject {

        val boundary = "SIPAMBoundary${System.currentTimeMillis()}"

        val url = URL(BASE_URL + endpoint)
        val connection = url.openConnection() as HttpURLConnection

        try {
            connection.requestMethod = "POST"
            connection.connectTimeout = 20000
            connection.readTimeout = 20000
            connection.doOutput = true

            connection.setRequestProperty(
                "Content-Type",
                "multipart/form-data; boundary=$boundary"
            )

            connection.setRequestProperty("Accept", "application/json")

            DataOutputStream(connection.outputStream).use { output ->

                // Mengirim semua data teks
                for ((key, value) in fields) {

                    output.writeBytes("--$boundary\r\n")
                    output.writeBytes(
                        "Content-Disposition: form-data; name=\"$key\"\r\n\r\n"
                    )

                    output.write(value.toByteArray(Charsets.UTF_8))
                    output.writeBytes("\r\n")
                }

                // Mengirim foto jika dipilih
                if (fotoUri != null) {

                    val mimeType = context.contentResolver
                        .getType(fotoUri) ?: "image/jpeg"

                    output.writeBytes("--$boundary\r\n")
                    output.writeBytes(
                        "Content-Disposition: form-data; name=\"foto\"; filename=\"bukti.jpg\"\r\n"
                    )
                    output.writeBytes(
                        "Content-Type: $mimeType\r\n\r\n"
                    )

                    context.contentResolver
                        .openInputStream(fotoUri)
                        ?.use { input ->
                            input.copyTo(output)
                        }
                        ?: throw Exception("Foto tidak dapat dibaca")

                    output.writeBytes("\r\n")
                }

                output.writeBytes("--$boundary--\r\n")
                output.flush()
            }

            val responseCode = connection.responseCode

            val responseStream =
                if (responseCode in 200..299) {
                    connection.inputStream
                } else {
                    connection.errorStream
                }

            val responseText = responseStream
                ?.bufferedReader()
                ?.use { it.readText() }
                ?: """{"status":false,"pesan":"Respons server kosong"}"""

            return JSONObject(responseText)

        } finally {
            connection.disconnect()
        }
    }
}
