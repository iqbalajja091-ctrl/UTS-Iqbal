
package com.example.sipamrt

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONObject

class RegisterActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)

        val nama = findViewById<EditText>(R.id.etNama)
        val telepon = findViewById<EditText>(R.id.etTelepon)
        val alamat = findViewById<EditText>(R.id.etAlamat)
        val email = findViewById<EditText>(R.id.etEmailDaftar)
        val password = findViewById<EditText>(R.id.etPasswordDaftar)

        val btnDaftar = findViewById<Button>(R.id.btnDaftar)
        val tvKembaliLogin =
            findViewById<TextView>(R.id.tvKembaliLogin)

        btnDaftar.setOnClickListener {

            val inputNama = nama.text.toString().trim()
            val inputTelepon = telepon.text.toString().trim()
            val inputAlamat = alamat.text.toString().trim()
            val inputEmail = email.text.toString().trim()
            val inputPassword = password.text.toString()

            if (
                inputNama.isEmpty() ||
                inputTelepon.isEmpty() ||
                inputAlamat.isEmpty() ||
                inputEmail.isEmpty() ||
                inputPassword.isEmpty()
            ) {
                Toast.makeText(
                    this,
                    "Semua kolom wajib diisi",
                    Toast.LENGTH_SHORT
                ).show()

                return@setOnClickListener
            }

            if (inputPassword.length < 8) {
                Toast.makeText(
                    this,
                    "Password minimal 8 karakter",
                    Toast.LENGTH_SHORT
                ).show()

                return@setOnClickListener
            }

            // Menyiapkan data JSON
            val data = JSONObject().apply {
                put("nama", inputNama)
                put("telepon", inputTelepon)
                put("alamat", inputAlamat)
                put("email", inputEmail)
                put("password", inputPassword)
            }

            btnDaftar.isEnabled = false
            btnDaftar.text = "Memproses..."

            // Menghubungi PHP API di background thread
            Thread {

                try {
                    val response = ApiClient.post(
                        "register.php",
                        data
                    )

                    val berhasil = response.optBoolean("status")
                    val pesan = response.optString("pesan")

                    runOnUiThread {

                        btnDaftar.isEnabled = true
                        btnDaftar.text = "Daftar"

                        Toast.makeText(
                            this,
                            pesan,
                            Toast.LENGTH_LONG
                        ).show()

                        if (berhasil) {
                            finish()
                        }
                    }

                } catch (e: Exception) {

                    runOnUiThread {

                        btnDaftar.isEnabled = true
                        btnDaftar.text = "Daftar"

                        Toast.makeText(
                            this,
                            "Gagal menghubungi server: ${e.message}",
                            Toast.LENGTH_LONG
                        ).show()
                    }
                }

            }.start()
        }

        tvKembaliLogin.setOnClickListener {
            finish()
        }
    }
}
