
package com.example.sipamrt

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private val handler = Handler(Looper.getMainLooper())

    private val splashRunnable = Runnable {
        if (!isFinishing && !isDestroyed) {
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Menggunakan desain dari activity_main.xml
        setContentView(R.layout.activity_main)

        // Pindah ke halaman login setelah 3 detik
        handler.postDelayed(splashRunnable, 3000)
    }

    override fun onDestroy() {
        handler.removeCallbacks(splashRunnable)
        super.onDestroy()
    }
}
